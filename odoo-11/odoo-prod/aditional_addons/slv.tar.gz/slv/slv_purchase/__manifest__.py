# -*- coding: utf-8 -*-
{
    'name': "SOLVOS purchase extension",

    'summary': """
        Purchase additions""",

    'description': """
        Purchase additions
		
		v0.1: 
    """,

    'author': "Solvos Consultoría Informática, S.L.",
    'website': "www.solvos.es",

    'category': 'Purchase',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['purchase'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/purchase_order.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}