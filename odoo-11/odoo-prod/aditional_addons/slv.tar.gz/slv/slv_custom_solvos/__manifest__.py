# -*- coding: utf-8 -*-
{
    'name': "SOLVOS Custom extension - SOLVOS",

    'summary': """
        SOLVOS additions for SOLVOS company""",

    'description': """
        SOLVOS additions for SOLVOS company
		
		v0.1:
		- Quotation report customization
    """,

    'author': "Solvos Consultoría Informática, S.L.",
    'website': "www.solvos.es",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base', 'account', 'sale'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}