# -*- coding: utf-8 -*-

from odoo import models, fields, api

# class slv_custum_solvos(models.Model):
#     _name = 'slv_custum_solvos.slv_custum_solvos'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100