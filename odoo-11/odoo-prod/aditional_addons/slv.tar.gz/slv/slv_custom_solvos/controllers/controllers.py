# -*- coding: utf-8 -*-
from odoo import http

# class SlvCustumSolvos(http.Controller):
#     @http.route('/slv_custum_solvos/slv_custum_solvos/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/slv_custum_solvos/slv_custum_solvos/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('slv_custum_solvos.listing', {
#             'root': '/slv_custum_solvos/slv_custum_solvos',
#             'objects': http.request.env['slv_custum_solvos.slv_custum_solvos'].search([]),
#         })

#     @http.route('/slv_custum_solvos/slv_custum_solvos/objects/<model("slv_custum_solvos.slv_custum_solvos"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('slv_custum_solvos.object', {
#             'object': obj
#         })