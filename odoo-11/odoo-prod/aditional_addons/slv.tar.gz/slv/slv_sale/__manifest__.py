# -*- coding: utf-8 -*-
{
    'name': "SOLVOS Sales extension",

    'summary': """
        Sales additions""",

    'description': """
        Sales additions
		
		v0.1: 
    """,

    'author': "Solvos Consultoría Informática, S.L.",
    'website': "www.solvos.es",

    'category': 'Sales',
    'version': '0.1',

    'depends': ['sale'],

    'data': [
        'views/sale_order.xml',
        'views/templates.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}