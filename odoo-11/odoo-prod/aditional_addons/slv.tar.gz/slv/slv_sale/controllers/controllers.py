# -*- coding: utf-8 -*-
from odoo import http

# class SlvSale(http.Controller):
#     @http.route('/slv_sale/slv_sale/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/slv_sale/slv_sale/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('slv_sale.listing', {
#             'root': '/slv_sale/slv_sale',
#             'objects': http.request.env['slv_sale.slv_sale'].search([]),
#         })

#     @http.route('/slv_sale/slv_sale/objects/<model("slv_sale.slv_sale"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('slv_sale.object', {
#             'object': obj
#         })