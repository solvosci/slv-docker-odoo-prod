# -*- coding: utf-8 -*-
from odoo import http

# class SlvStock(http.Controller):
#     @http.route('/slv_stock/slv_stock/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/slv_stock/slv_stock/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('slv_stock.listing', {
#             'root': '/slv_stock/slv_stock',
#             'objects': http.request.env['slv_stock.slv_stock'].search([]),
#         })

#     @http.route('/slv_stock/slv_stock/objects/<model("slv_stock.slv_stock"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('slv_stock.object', {
#             'object': obj
#         })