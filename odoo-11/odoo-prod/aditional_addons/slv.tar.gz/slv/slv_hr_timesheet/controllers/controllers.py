# -*- coding: utf-8 -*-
from odoo import http

# class SlvHrTimesheet(http.Controller):
#     @http.route('/slv_hr_timesheet/slv_hr_timesheet/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/slv_hr_timesheet/slv_hr_timesheet/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('slv_hr_timesheet.listing', {
#             'root': '/slv_hr_timesheet/slv_hr_timesheet',
#             'objects': http.request.env['slv_hr_timesheet.slv_hr_timesheet'].search([]),
#         })

#     @http.route('/slv_hr_timesheet/slv_hr_timesheet/objects/<model("slv_hr_timesheet.slv_hr_timesheet"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('slv_hr_timesheet.object', {
#             'object': obj
#         })