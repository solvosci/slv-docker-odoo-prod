# -*- coding: utf-8 -*-

from odoo import api, fields, models


class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    # Overrides name type (Char -> Text)
    name = fields.Text('Description', required=True)

    day_of_week = fields.Selection(
        [(1, 'Monday'), (2, 'Tuesday'), (3, 'Wednesday'), (4, 'Thursday'), (5, 'Friday'), (6, 'Saturday'), (7, 'Sunday')],
        string='Day of week',
        readonly=True,
        compute='_get_day_of_week',
        store=True
    )

    @api.multi
    @api.depends('name')
    def name_get(self):
        def _desc_substring(desc, max_length=50):
            ret = desc[0:max_length]
            if len(desc) > max_length:
                ret += '...'
            return ret
        result = []
        for line in self:
            name = _desc_substring(line.name)
            result.append((line.id, name))
        return result

    @api.multi
    @api.depends('date')
    def _get_day_of_week(self):
        for line in self:
            line.day_of_week = fields.Date.from_string(line.date).weekday() + 1
