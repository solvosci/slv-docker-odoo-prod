Solvos Timesheets extension
---------------------------

TODO: insert here a detailed description about this application