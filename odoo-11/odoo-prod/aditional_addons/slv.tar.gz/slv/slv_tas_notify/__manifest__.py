# -*- coding: utf-8 -*-
{
    'name': "Technical Assistance Service - notifications",
    'summary': "Notifications for Technical Assistance Service (TAS)",
    'author': "Solvos Consultoría Informática",
    "license": "AGPL-3",
    "website": "www.solvos.es",
    "category": "Project",
    "version": "11.0.1.1.0",
    'depends': [
        'slv_tas',
        'web_notify'
    ],
    'data': [],
    'demo': [],
    'installable': True,
    'application': False,
}