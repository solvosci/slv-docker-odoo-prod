# -*- coding: utf-8 -*-

import logging
from odoo import models, api, _

_logger = logging.getLogger(__name__)


class Case(models.Model):
    _inherit = 'slv.tas.case'

    @api.multi
    def _send_activity_reminder(self):
        super(Case, self)._send_activity_reminder()
        # After email reminders, only one per-user IM notification will be sent
        try:
            case_assigned_to_ids = self.mapped('assigned_to_id')
            _logger.info('Found %d assigned users' % len(case_assigned_to_ids))
            for assigned_to_id in case_assigned_to_ids:
                case_num = len(self.filtered(lambda c: c.assigned_to_id.id == assigned_to_id.id))
                assigned_to_id.notify_info(
                    message=_('You have %d CRM cases with no activity during the last days, '
                              'and email reminders have been sent') % case_num,
                    title=_('New case reminders'),
                    sticky=True)
                _logger.info('Sent notification to %s' % assigned_to_id.name)
        except Exception as e:
            _logger.error('Unable to send longpolling notifications: %s' % e)
