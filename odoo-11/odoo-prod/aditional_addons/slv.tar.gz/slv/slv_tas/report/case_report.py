# -*- coding: utf-8 -*-

from odoo import models, fields, tools, _


class ReportMonthlyCases(models.Model):
    """
    View-mode model that ists cases & actions in order to be filtered by month and exported to Excel
    """
    _name = 'report.slv.tas.case.monthly'
    _inherit = ['slv.tas.base.case']
    _description = 'TAS monthly summary'
    _order = 'name'
    _auto = False

    # TODO look for a generic model
    def _get_case_start_month(self):
        return [
            ('1', _('January')),
            ('2', _('February')),
            ('3', _('March')),
            ('4', _('April')),
            ('5', _('May')),
            ('6', _('June')),
            ('7', _('July')),
            ('8', _('August')),
            ('9', _('September')),
            ('10', _('October')),
            ('11', _('November')),
            ('12', _('December')),
        ]

    name = fields.Char('Case #', readonly=True)
    start_date = fields.Datetime('Start date', readonly=True)
    description = fields.Char('Description', readonly=True)
    answer = fields.Text('Answer', readonly=True)
    end_date = fields.Datetime('End date', readonly=True)
    status_id = fields.Many2one('slv.tas.case.status', string='Status', readonly=True)
    action_sequence = fields.Integer('Sequence', readonly=True)
    action_subject = fields.Text('Subject', readonly=True)
    action_start_date = fields.Datetime('Action start date', readonly=True)
    action_hours = fields.Float('Hours', readonly=True)
    action_note = fields.Text('Action note', readonly=True)
    action_end_date = fields.Datetime('Action end date', readonly=True)
    action_status_id = fields.Many2one('slv.tas.case.action.status', string='Action status', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Customer', readonly=True)
    contact_id = fields.Many2one('res.partner', string='Contact', readonly=True)
    classification_id = fields.Many2one('slv.tas.case.classification', string='Classification', readonly=True)
    subtype_id = fields.Many2one('slv.tas.case.subtype', string='Subtype', readonly=True)

    #type = fields.Selection(selection='_get_case_type_selection', string='Type', readonly=True)
    type_id = fields.Many2one('slv.tas.case.type', string='Type', readonly=True)
    case_start_year = fields.Integer('Year', readonly=True)
    case_start_month = fields.Selection(selection='_get_case_start_month', string='Month', readonly=True)

    status = fields.Char('Status code', readonly=True)

    def _select(self):
        select_str = """
             SELECT
                    tca.id as id,
                    tc.name as name,
                    tc.start_date as start_date,
                    tc.description as description,
                    tc.answer as answer,
                    tc.end_date as end_date,
                    tc.status_id as status_id,
                    tca.sequence as action_sequence,
                    tca.subject as action_subject,
                    tca.start_date as action_start_date,
                    tca.hours as action_hours,
                    tca.note as action_note,
                    tca.end_date as action_end_date,
                    tca.status_id as action_status_id,
                    tc.partner_id as partner_id,
                    tc.contact_id as contact_id,
                    tc.classification_id as classification_id,
                    tc.subtype_id as subtype_id,
                    
                    tc.type_id as type_id,
                    tc.status as status,
                    EXTRACT(YEAR FROM tc.start_date) as case_start_year,
                    CAST(EXTRACT(MONTH FROM tc.start_date) as text) as case_start_month
        """

        return select_str

    def _group_by(self):
        group_by_str = ''
        return group_by_str

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE view %s as
              %s
              FROM slv_tas_case tc
              INNER JOIN slv_tas_case_action tca ON tca.case_id=tc.id
              WHERE 1=1
              %s
        """ % (self._table, self._select(), self._group_by()))