# -*- coding: utf-8 -*-

from . import case_report