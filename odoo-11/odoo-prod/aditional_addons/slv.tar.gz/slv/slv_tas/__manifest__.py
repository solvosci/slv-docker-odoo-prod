# -*- coding: utf-8 -*-
# Copyright 2018 Solvos Consultoría Informática, S.L. <solvos@solvos.es>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

{
    "name": "Technical Assistance Service",
    'summary': "Technical Assistance Service (TAS) for software project maintenance",
    "version": "11.0.1.1.0",
    "author": "Solvos Consultoría Informática",
    "license": "AGPL-3",
    "website": "www.solvos.es",
    "category": "Project",
    'depends': [
		'crm'
	],
	'data' : [
        'data/case_data.xml',
        'security/groups.xml',
        'security/ir.model.access.csv',
        'views/res_config_settings.xml',
		'views/case_views.xml',
		'views/case_menuitem.xml',
        'report/case_report_views.xml',
        'report/case_report_menuitem.xml',
        'report/case_report_template.xml',
        'report/case_report.xml',
	],
    'installable': True,	
    'application': False,
}
