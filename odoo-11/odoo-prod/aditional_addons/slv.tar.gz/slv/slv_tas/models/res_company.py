from dateutil.relativedelta import relativedelta
from odoo import fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    def _default_case_email_greeting_datetime(self):
        return fields.Datetime.to_string(fields.datetime.now() +
                                         relativedelta(hour=12, minute=0, second=0))

    case_email_greeting_datetime = fields.Datetime(
        'TAS Greeting datetime',
        default=_default_case_email_greeting_datetime)
