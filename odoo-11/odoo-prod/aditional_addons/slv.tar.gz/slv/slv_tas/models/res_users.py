from odoo import models, fields, api


class ResUsers(models.Model):
    _inherit = 'res.users'

    tas_is_manager = fields.Boolean(
        'Is TAS manager',
        compute='_compute_tas_is_manager',
        store=True)

    @api.depends('groups_id')
    def _compute_tas_is_manager(self):
        for user in self:
            user.tas_is_manager = user.has_group('slv_tas.group_tas_manager')
