from odoo import models, fields


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    group_case_email_template = fields.Boolean(
        'Generate case email templates',
        group='base.group_user',
        implied_group='slv_tas.group_case_email_template')
    case_email_greeting_datetime = fields.Datetime(
        'Greeting datetime',
        related='company_id.case_email_greeting_datetime')
    module_slv_tas_notify = fields.Boolean(
        'Case reminder notifications')
