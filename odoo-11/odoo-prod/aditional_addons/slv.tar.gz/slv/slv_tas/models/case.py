# -*- coding: utf-8 -*-

import logging
import datetime
import dateutil
from dateutil.relativedelta import relativedelta

from odoo import api, models, fields, _
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as DF

_logger = logging.getLogger(__name__)


class BaseCase(models.AbstractModel):
    """
    Allocates common functionality for Cases modules
    """
    _name = 'slv.tas.base.case'
    _description = 'Base Case model'


class BaseCategory(models.AbstractModel):
    """
    Represents a category model template

    TODO code, default should be unique values
    """
    _name = 'slv.tas.base.category'
    _description = 'Base category'
    _order = 'code'
    _sql_constraints = [('code_uniq', 'UNIQUE (code)', 'Code must be unique')]

    code = fields.Char('Code', required=True)
    name = fields.Char('Description', required=True, translate=True)
    default = fields.Boolean('Is default value', default=False)
    active = fields.Boolean('Active', default=True)

    def _process_default(self, values, category_id=None):
        """
        Ensure that only one record is marked as default
        :param values: values to be inserted/updated
        :param id: record id (if is an update)
        :return:
        """
        if ('default' in values) and values.get('default'):
            domain = [] if category_id is None else [('id','!=',category_id)]
            for category in self.search(domain):
                category.default = False

    @api.model
    def create(self, values):
        self._process_default(values)
        return super(BaseCategory, self).create(values)

    @api.multi
    def write(self, values):
        self.ensure_one()
        self._process_default(values, category_id=self.id)
        return super(BaseCategory, self).write(values)

    def get_default_id(self):
        first_default_category = self.search([('default', '=', True)], order='code', limit=1)
        if first_default_category:
            return first_default_category.id
        else:
            return None


class CaseType(models.Model):
    _name = 'slv.tas.case.type'
    _description = 'Case type'
    _inherit = ['slv.tas.base.category']

    subtype_ids = fields.One2many('slv.tas.case.subtype', 'type_id', string='Subtypes',
                                  copy=False, auto_join=True)


class CaseSubtype(models.Model):
    _name = 'slv.tas.case.subtype'
    _description = 'Case subtype'
    _inherit = ['slv.tas.base.category']
    _sql_constraints = [('code_uniq', 'UNIQUE (type_id,code)', 'Code must be unique within a type')]

    type_id = fields.Many2one('slv.tas.case.type', string='Type', required=True, ondelete='cascade',
                              index=True, copy=False)


class CaseClassification(models.Model):
    _name = 'slv.tas.case.classification'
    _description = 'Case classification'
    _inherit = ['slv.tas.base.category']


class CaseStatus(models.Model):
    _name = 'slv.tas.case.status'
    _description = 'Case status'
    _inherit = ['slv.tas.base.category']

    def get_status_closed_id(self):
        # return self.browse(5).id
        # TODO protect code
        return self.search([('code','=','99')]).id

    @api.multi
    def unlink(self):
        self.ensure_one()
        protected_statuses = ('99',)
        if self.code in protected_statuses:
            raise UserError(_('Case status %s-%s cannot be deleted') % (self.code, self.name))
        return super(CaseStatus, self).unlink()


class CaseMailTemplate(models.TransientModel):
    _name='slv.tas.case.wizard'
    _inherit = ['slv.tas.base.case']
    _description = 'Case Mail Template'

    name = fields.Char('Case #')
    greeting = fields.Char('Greeting')
    description = fields.Char('Description')
    partner_id = fields.Many2one('res.partner', string='Customer')
    contact_id = fields.Many2one('res.partner', string='Contact')
    partner_name = fields.Char('Customer')
    contact_name = fields.Char('Contact')
    partner_email = fields.Char('Customer Email')
    contact_email = fields.Char('Contact Email')
    #type = fields.Selection(selection='_get_case_type_selection', string='Type')
    type_id = fields.Many2one('slv.tas.case.type', string='Type')
    #subtype = fields.Selection(selection='_get_case_subtype_selection', string='Subtype')
    subtype_id = fields.Many2one('slv.tas.case.subtype', string='Subtype')
    #classification = fields.Selection(selection='_get_case_classification_selection', string='Classification')
    classification_id = fields.Many2one('slv.tas.case.classification', string='Classification')
    #status = fields.Selection(selection='_get_case_status_selection', string='Status')
    status_id = fields.Many2one('slv.tas.case.status', string='Status')
    answer = fields.Text('Answer')
    start_date = fields.Datetime('Start date')
    end_date = fields.Datetime('End date')


    @api.multi
    def action_case_mail_cancel(self):
        '''
        Shortcut to cancel in mail template to send to the partner (customer)
        :return:
        '''
        return True


class Case(models.Model):
    """
    Main data for a TAS Case (ticket)
    """
    _name = 'slv.tas.case'
    _inherit = ['slv.tas.base.case']
    _description = 'Case'
    _order = 'write_date desc'

    def _default_year(self):
        return fields.Date.from_string(fields.Date.today()).year

    def _default_start_date(self):
        #return fields.Datetime.from_string(fields.Datetime.now())
        return fields.Datetime.now()

    def _default_type_id(self):
        return self.env['slv.tas.case.type'].get_default_id()

    def _default_status_id(self):
        return self.env['slv.tas.case.status'].get_default_id()

    def _default_assigned_to_id(self):
        return self.env.user

    year = fields.Integer('Year')
    case_num = fields.Integer('Number')
    name = fields.Char('Case #')
    partner_id = fields.Many2one('res.partner', string='Customer',
                                 required=True)
    contact_id = fields.Many2one('res.partner', string='Contact',
                                 required=True)
    description = fields.Char('Description', required=True, copy=False)
    type_id = fields.Many2one('slv.tas.case.type', string='Type', required=True, default=_default_type_id)
    subtype_id = fields.Many2one('slv.tas.case.subtype', string='Subtype', required=True)
    classification_id = fields.Many2one('slv.tas.case.classification', string='Classification', required=True)
    status_id = fields.Many2one('slv.tas.case.status', string='Status', required=True, copy=False,
                                default=_default_status_id)
    answer = fields.Text('Answer', copy=False)
    start_date = fields.Datetime('Start date', required=True, copy=False, default=_default_start_date)
    end_date = fields.Datetime('End date', copy=False)

    total_hours = fields.Float('Total hours', readonly=True, default=0, compute='_compute_total_hours')
    status = fields.Char('Status code', readonly=True, compute='_compute_status_code')

    case_action = fields.One2many('slv.tas.case.action', 'case_id', string='Case Actions',
                                  copy=False, auto_join=True)
    calendar_end_date = fields.Datetime('Calendar End date', readonly=True, compute='compute_calendar_end')
    assigned_to_id = fields.Many2one(
        'res.users',
        string='Assigned to',
        default=_default_assigned_to_id
        # domain=[('tas_is_manager', '=', True)]
    )

    @api.model
    def create(self, vals):
        vals = self._case_preprocess(vals)
        return super(Case, self).create(vals)    
    
    def _case_preprocess(self, vals):
        """
        Deduce other field values from the given one.
        Override this to compute on the fly some field that can not be computed fields.
        :param vals: dict values for `create`or `write`.
        """        
        for i in vals:
            _logger.info("[SLV] %s=%s", i, vals.get(i))
        # * Description: form required, but unset when duplicated
        if not vals.get('description'):
            vals['description'] = _('Insert here the new description')
        # * Start date: same as description
        if not vals.get('start_date'):
            vals['start_date'] = self._default_start_date()
        # * Year of the case: the same of the start date
        vals['year'] = fields.Datetime.from_string(vals.get('start_date')).year
        # * Case number: determined for a sequence by year
        last_case = self.search([('year','=',vals['year'])], order='case_num desc', limit=1)
        case_max_num = 1
        if last_case:
            case_max_num = last_case.case_num + 1
        vals['case_num'] = case_max_num
        vals['name'] = "{0:d}/{1:06d}".format(vals['year'], case_max_num)
            
        return vals

    def compute_calendar_end(self):
        """
        Sets virtual calendar_end_date = last month day
        :return:
        """
        for case in self:
            if not case.end_date:
                case.calendar_end_date = fields.Datetime.to_string(fields.datetime.now() + dateutil.relativedelta.relativedelta(months=+1, day=1, days=-1))
            else:
                case.calendar_end_date = case.end_date

    @api.multi
    def write(self, values):
        self.ensure_one()
        # Modifying a case is not allowed whether status remains Closed
        status_id = self.status_id.id
        new_status_id = status_id
        if 'status_id' in values:
            new_status_id = values.get('status_id')
        status_close_id = self.env['slv.tas.case.status'].get_status_closed_id()
        if (status_id == status_close_id) & (new_status_id == status_close_id):
            raise UserError(_('Case edition is not allowed when status is Closed.'
                            ' If you want to change case data, try to change the status too'))
        return super(Case, self).write(values)

    @api.multi
    def unlink(self):
        # TODO forbid multiple deletion
        for case in self:
            if case.status_id.code == '99':
                raise UserError(_('Cannot delete case # %s because its status is Closed') % case.name)
        return super(Case, self).unlink()

    @api.depends('status_id')
    def _compute_status_code(self):
        """
        Copies the status code to the case
        :return:
        """
        for case in self:
            case.status = case.status_id.code

    @api.depends('case_action.hours')
    def _compute_total_hours(self):
        """
        Sets the case total hours, which are the sum of the action hours
        :return:
        """
        for case in self:
            case.total_hours = sum(case.case_action.mapped('hours'))

    @api.multi
    @api.depends('name', 'description')
    def name_get(self):
        def _desc_substring(desc, max_length=50):
            ret = desc[0:max_length]
            if len(desc) > max_length:
                ret += '...'
            return ret
        result = []
        for case in self:
            name = "{0:s} - {1:s}".format(case.name, _desc_substring(case.description))
            result.append((case.id, name))
        return result

    @api.multi
    def action_case_close(self):
        '''
        Shortcut to change case to 'Closed' status with additional stuff
        :return:
        '''
        self.ensure_one()
        if not self.answer:
            raise UserError(_('Answer is not filled yet'))
        if self.status_id.code == '99':
            raise UserError(_('Case is already closed'))
        if not self.end_date:
            self.end_date = self._default_start_date()
        self.status_id = self.env['slv.tas.case.status'].get_status_closed_id()
        # TODO go back to case list
        return True

    @api.multi
    def action_case_mail(self):
        '''
        Shortcut to create a mail template to send to the partner (customer)
        :return:
        '''
        self.ensure_one()
        if not self.name or not self.description:
            raise UserError(_('Name and Description is not filled yet'))
        #
        my_company = self.env['res.company']._company_default_get('slv_tas')
        now = datetime.datetime.now()
        now_mins = (now.hour * 60) + now.minute
        dt_greeting = fields.Datetime.from_string(my_company.case_email_greeting_datetime)
        txtgreeting = 'Buenos días'
        if now_mins > ((dt_greeting.hour * 60) + dt_greeting.minute):
            txtgreeting = 'Buenas tardes'
        partner_model = self.env['res.partner']
        params = {
            'name': self.name,
            'greeting': txtgreeting,
            'description': self.description,
            'partner_id': self.partner_id.id,
            'partner_email': self.partner_id.email,
            'contact_id': self.contact_id.id,
            'contact_name': self.contact_id.name,
            'contact_email': self.contact_id.email,
            'type_id': self.type_id.id,
            'subtype_id': self.subtype_id.id,
            'classification_id': self.classification_id.id,
            'status_id': self.status_id.id,
            'answer': self.answer,
            'start_date': self.start_date,
            'end_date': self.end_date
            }
        view_id = self.env['slv.tas.case.wizard']
        new = view_id.create(params)
        return {
            'name': '%s. %s. Incidencia SaiCyt %s' % (self.partner_id.comercial, self.contact_id.name, self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'slv.tas.case.wizard',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': new.id,
            'target': 'new'
        }

    # This method should be called once a day by the scheduler
    @api.model
    def _send_activity_reminder_all(self):
        # This process is skipped on weekend
        if fields.datetime.now().weekday() in (5, 6):
            return
        reminder_date = fields.datetime.now() - datetime.timedelta(days=7)
        cases = self.search([('status_id', '!=', self.env['slv.tas.case.status'].get_status_closed_id()),
                             ('write_date', '<=', reminder_date.strftime(DF))])
        if cases:
            cases._send_activity_reminder()
            cases._update_activity_reminder()

    @api.multi
    def _send_activity_reminder(self):
        """
        Sends email notifications of case activity reminders
        :return:
        """
        ##### LONGPOLLING NOTIFICATIONS ##################
        # The code below has been replaced by slv_tas_notify module
        """
        try:
            # Notifications will be sent X minutes after the email messages
            delta = 1 * 60
            notifications = []
            for case in self:
                notifications.append([(self._cr.dbname, 'slv.tas.case', case.assigned_to_id.partner_id.id), {
                    'event_id': case.id,
                    'title': case.name,
                    'message': case.description,
                    'timer': delta,
                    'notify_at': fields.Datetime.to_string(fields.datetime.now() + relativedelta(seconds=delta)),
                }])
            if len(notifications) > 0:
                self.env['bus.bus'].sendmany(notifications)
                _logger.info('Sent %d notifications' % len(notifications))
        except Exception as e:
            _logger.error('Unable to send longpolling notifications: %s' % e)
        """
        ##### end LONGPOLLING NOTIFICATIONS ###############

        # Standard email notification
        Template = self.env.ref('slv_tas.email_template_case_activity_reminder')
        for case in self:
            Template.with_context(lang=case.assigned_to_id.lang).send_mail(case.id, force_send=True)

    @api.multi
    def _update_activity_reminder(self):
        for case in self:
            case.write({
                'case_action': [(0, 0, {
                    'case_id': case.id,
                    'sequence': 0,
                    'subject': _('Activity reminder'),
                    'assigned_to_id': case.assigned_to_id.id,
                    'assignment_date': fields.Date.today(),
                    'start_date': fields.Date.today(),
                    'note': _('This is an automatically generated reminder of case inactivity')
                })]
            })


class CaseActionStatus(models.Model):
    _name = 'slv.tas.case.action.status'
    _description = 'Case action Status'
    _inherit = ['slv.tas.base.category']


class CaseAction(models.Model):
    """
    Detailed data for a TAS Case (ticket)
    """
    _name = 'slv.tas.case.action'
    _inherit = ['slv.tas.base.case', 'mail.thread']
    _description = 'Case action'
    _order = 'sequence'
    _sql_constraints = [('sequence_uniq', 'UNIQUE (case_id,sequence)', 'Action sequence must be unique within a case')]

    def _default_status_id(self):
        return self.env['slv.tas.case.action.status'].get_default_id()

    case_id = fields.Many2one('slv.tas.case', string='Case Reference',
                              required=True, ondelete='cascade', index=True, copy=False)
    sequence = fields.Integer('Sequence')
    subject = fields.Text('Subject', required=True)
    assigned_to_id = fields.Many2one('res.users', string='Assigned to',
                                     index=True, default=lambda self: self.env.user)
    assignment_date = fields.Date('Assignment date')
    start_date = fields.Date('Action start date')
    end_date = fields.Date('Action end date')
    status_id = fields.Many2one('slv.tas.case.action.status', string='Status', default=_default_status_id)
    note = fields.Text('Note')
    hours = fields.Float('Hours', default=0)

    status = fields.Char('Status code', readonly=True, compute='_compute_status_code')

    @api.model
    def create(self, values):
        _logger.info("[SLV] case_create")
        values = self._case_action_preprocess(values)
        return super(CaseAction, self).create(values)

    @api.depends('status_id')
    def _compute_status_code(self):
        """
        Copies the status code to the case
        :return:
        """
        for case_action in self:
            case_action.status = case_action.status_id.code

    def _case_action_preprocess(self, values):
        """
        Deduce other field values from the given one.
        Override this to compute on the fly some field that can not be computed fields.
        :param vals: dict values for `create`or `write`.
        :return:
        """
        # 'sequence' can be filled by the user, in that case the SQL constraint will check the uniqueness of the value;
        #  otherwise, its value is set as the highest value + 1
        if ('case_id' in values) and (values.get('sequence') == 0):
            # Sequence calculation
            last_action = self.search([('case_id', '=', values.get('case_id'))], order='sequence desc', limit=1)
            seq = 1
            if last_action:
                seq = last_action.sequence + 1
            values['sequence'] = seq
        return values
