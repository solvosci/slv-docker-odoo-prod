def migrate(cr, version):
    # slv_tas_case.status is moved to slv_tas_case.status_id
    cr.execute(
        'update slv_tas_case ca '
        'set status_id=( '
        '   select cas.id '
        '   from slv_tas_case_status cas '
        '   where cas.code=ca.status '
        ') '
        'where status is not null')
    # slv_tas_case.type is moved to slv_tas_case.type_id
    cr.execute(
        'update slv_tas_case ca '
        'set type_id=( '
        '   select cat.id '
        '   from slv_tas_case_type cat '
        '   where cat.code=ca.type '
        ') '
        'where type is not null')
    # slv_tas_case.subtype is moved to slv_tas_case.subtype_id
    cr.execute(
        'update slv_tas_case ca '
        'set subtype_id=( '
        '   select casub.id '
        '   from slv_tas_case_subtype casub '
        '   where casub.code=ca.subtype '
        ') '
        'where subtype is not null')
    # slv_tas_case.classification is moved to slv_tas_case.classification_id
    cr.execute(
        'update slv_tas_case ca '
        'set classification_id=( '
        '   select cac.id '
        '   from slv_tas_case_classification cac '
        '   where cac.code=ca.classification '
        ') '
        'where classification is not null')
    # slv_tas_case_action.status is moved to slv_tas_case_action.status_id
    cr.execute(
        'update slv_tas_case_action ca '
        'set status_id=( '
        '   select cas.id '
        '   from slv_tas_case_action_status cas '
        '   where cas.code=ca.status'
        ') '
        'where status is not null')

