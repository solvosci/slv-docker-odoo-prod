def migrate(cr, version):
    pass