def migrate(cr, version):
    # slv_tas_case.assigned_to_id should be the last action user or Administrator user
    cr.execute("""
        update slv_tas_case tc
        set assigned_to_id=coalesce((
            select tca.assigned_to_id
            from slv_tas_case_action tca
            where tca.case_id=tc.id
            order by tca.sequence desc
            limit 1
        ), 1)
    """)
