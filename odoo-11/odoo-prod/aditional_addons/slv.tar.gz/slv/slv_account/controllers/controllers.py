# -*- coding: utf-8 -*-
from odoo import http

# class SlvAccount(http.Controller):
#     @http.route('/slv_account/slv_account/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/slv_account/slv_account/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('slv_account.listing', {
#             'root': '/slv_account/slv_account',
#             'objects': http.request.env['slv_account.slv_account'].search([]),
#         })

#     @http.route('/slv_account/slv_account/objects/<model("slv_account.slv_account"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('slv_account.object', {
#             'object': obj
#         })