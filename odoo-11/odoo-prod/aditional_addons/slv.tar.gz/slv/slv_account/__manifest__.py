# -*- coding: utf-8 -*-
{
    'name': "SOLVOS Account extension",

    'summary': """
        Account additions""",

    'description': """
        Account additions
		
		v0.1: 
    """,

    'author': "Solvos Consultoría Informática, S.L.",
    'website': "www.solvos.es",

    'category': 'Account',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['account'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/account_invoice.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}